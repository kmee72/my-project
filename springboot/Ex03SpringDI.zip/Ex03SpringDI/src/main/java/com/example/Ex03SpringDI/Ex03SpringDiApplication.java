package com.example.Ex03SpringDI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex03SpringDiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex03SpringDiApplication.class, args);
	}

}
